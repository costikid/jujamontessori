<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];

    $to = "jujajuniormontessori@gmail.com"; // Replace with your email address
    $subject = "New Contact Form Submission";
    $headers = "From: $email";

    $messageContent = "Name: $name\nEmail: $email\nPhone: $phone\nMessage:\n$message";

    mail($to, $subject, $messageContent, $headers);

   
}
?>
